import csv
import os

def extraire_contenu_fichier(nom_fichier):
    with open(nom_fichier, 'r', encoding='utf-8') as fichier:  # Remplacez 'ISO-8859-1' par l'encodage correct de vos fichiers
        lignes = fichier.readlines()
    
    titre = ""
    contenu = ""
    enregistre_contenu = False

    for ligne in lignes:
        if ligne.startswith("Title"):
            titre = ligne[len("Title"):].strip()
        elif ligne.startswith("Content"):
            enregistre_contenu = True
            contenu = ligne[len("Content"):].strip()
        elif enregistre_contenu:
            contenu += ligne.strip()

    return titre, contenu

def creer_csv(liste_fichiers, nom_csv):
    with open(nom_csv, 'w', newline='', encoding='utf-8') as fichier_csv:
        csv_writer = csv.writer(fichier_csv, delimiter=',')
        csv_writer.writerow(['Titre', 'Contenu'])

        for fichier in liste_fichiers:
            titre, contenu = extraire_contenu_fichier(fichier)
            csv_writer.writerow([titre, contenu])

if __name__ == "__main__":
    # Remplacez 'chemin_du_dossier' par le chemin du dossier contenant vos fichiers texte
    chemin_du_dossier = './'
    
    # Liste tous les fichiers texte dans le dossier
    fichiers_texte = [f for f in os.listdir(chemin_du_dossier) if f.endswith('.txt')]

    # Crée le CSV avec les données extraites
    creer_csv(fichiers_texte, 'donnees.csv')
